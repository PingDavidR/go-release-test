# GitHub Actions Integration Snippets

Ready-to-use GitHub Actions workflows for changelog validation and automation.

## Overview

This document provides GitHub Actions snippets for:
1. **Optional changelog validation** - Validates format if changelog exists
2. **Strict changelog enforcement** - Requires changelog for all PRs (not recommended)
3. **Automated release notes** - Generates release notes on tag push

---

## 1. Optional Changelog Validation (Recommended)

This workflow validates changelog format **only if a changelog file exists**. PRs without changelogs will pass.

**File:** `.github/workflows/verify-changelog.yml`

```yaml
name: Verify Changelog Format

on:
  pull_request:
    branches:
      - main
      - develop
    paths:
      - '.changelog/pr-*.txt'

jobs:
  verify-changelog:
    name: Verify Changelog Entry Format
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
      
      - name: Verify Changelog Format
        env:
          PR_NUMBER: ${{ github.event.pull_request.number }}
        run: |
          CHANGELOG_FILE=".changelog/pr-${PR_NUMBER}.txt"
          
          if [ ! -f "$CHANGELOG_FILE" ]; then
            echo "ℹ️ No changelog file found (changelog is optional)"
            exit 0
          fi
          
          echo "📝 Validating changelog format for $CHANGELOG_FILE"
          
          # Extract fields
          TYPE=$(grep "^type:" "$CHANGELOG_FILE" | sed 's/^type:[[:space:]]*//')
          DESCRIPTION=$(grep "^description:" "$CHANGELOG_FILE" | sed 's/^description:[[:space:]]*//')
          PR=$(grep "^pr:" "$CHANGELOG_FILE" | sed 's/^pr:[[:space:]]*//')
          TICKET=$(grep "^ticket:" "$CHANGELOG_FILE" | sed 's/^ticket:[[:space:]]*//')
          
          # Check required fields exist
          MISSING_FIELDS=""
          [ -z "$TYPE" ] && MISSING_FIELDS="${MISSING_FIELDS}type, "
          [ -z "$DESCRIPTION" ] && MISSING_FIELDS="${MISSING_FIELDS}description, "
          [ -z "$PR" ] && MISSING_FIELDS="${MISSING_FIELDS}pr, "
          [ -z "$TICKET" ] && MISSING_FIELDS="${MISSING_FIELDS}ticket, "
          
          if [ -n "$MISSING_FIELDS" ]; then
            echo "::error::Missing required fields: ${MISSING_FIELDS%, }"
            exit 1
          fi
          
          # Validate type
          VALID_TYPES="breaking|feature|enhancement|bugfix|note|security|deprecation|internal"
          if ! echo "$TYPE" | grep -qE "^($VALID_TYPES)$"; then
            echo "::error::Invalid type '$TYPE'. Must be one of: breaking, feature, enhancement, bugfix, note, security, deprecation, internal"
            exit 1
          fi
          
          # Validate PR number matches
          if [ "$PR" != "$PR_NUMBER" ]; then
            echo "::warning::PR number in changelog ($PR) doesn't match actual PR ($PR_NUMBER)"
          fi
          
          # Validate Jira ticket format (if not N/A)
          if [ "$TICKET" != "N/A" ] && ! echo "$TICKET" | grep -qE "^(CDI|PDI)-[0-9]+$"; then
            echo "::error::Invalid Jira ticket format '$TICKET'. Must be CDI-### or PDI-### or N/A"
            exit 1
          fi
          
          echo "✅ Changelog format is valid"
          echo ""
          echo "Type: $TYPE"
          echo "Description: $DESCRIPTION"
          echo "PR: $PR"
          echo "Ticket: $TICKET"
```

---

## 2. Strict Changelog Enforcement (Not Recommended)

**Use this only if you want to require changelog entries for ALL PRs.**

Add this step to your main CI pipeline (e.g., `.github/workflows/ci.yml`):

```yaml
      - name: Require Changelog Entry
        if: github.event_name == 'pull_request'
        env:
          PR_NUMBER: ${{ github.event.pull_request.number }}
        run: |
          CHANGELOG_FILE=".changelog/pr-${PR_NUMBER}.txt"
          
          if [ ! -f "$CHANGELOG_FILE" ]; then
            echo "::error::Changelog file $CHANGELOG_FILE is required for all PRs"
            echo "::error::Run: ./scripts/create-changelog.sh $PR_NUMBER <type> \"<description>\""
            exit 1
          fi
          
          echo "✅ Changelog file exists"
```

**Note:** This is generally **not recommended** as it blocks PRs without changelogs.

---

## 3. Automated Release Notes Generation

Generate release notes automatically when a version tag is pushed.

**File:** `.github/workflows/release-notes.yml`

```yaml
name: Generate Release Notes

on:
  push:
    tags:
      - 'v*.*.*'

jobs:
  generate-release-notes:
    name: Generate and Publish Release Notes
    runs-on: ubuntu-latest
    permissions:
      contents: write
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
      
      - name: Extract version from tag
        id: version
        run: echo "VERSION=${GITHUB_REF#refs/tags/}" >> $GITHUB_OUTPUT
      
      - name: Generate release notes
        run: |
          chmod +x scripts/generate-release-notes.sh
          ./scripts/generate-release-notes.sh
      
      - name: Create GitHub Release
        uses: softprops/action-gh-release@v1
        with:
          tag_name: ${{ steps.version.outputs.VERSION }}
          name: Release ${{ steps.version.outputs.VERSION }}
          body_path: GITHUB_RELEASE_NOTES.md
          draft: false
          prerelease: false
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Archive changelog entries
        run: |
          chmod +x scripts/archive-changelog.sh
          ./scripts/archive-changelog.sh ${{ steps.version.outputs.VERSION }}
      
      - name: Commit archived changelogs
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          git add .changelog/archive/
          git commit -m "Archive changelog entries for ${{ steps.version.outputs.VERSION }}" || echo "No changes to commit"
          git push origin HEAD:main || echo "No changes to push"
```

---

## 4. Combined CI Pipeline Integration

Example of integrating optional changelog validation into an existing CI pipeline:

**File:** `.github/workflows/ci.yml`

```yaml
name: CI Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Run tests
        run: make test
  
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Run linters
        run: make lint
  
  verify-changelog:
    name: Verify Changelog (Optional)
    runs-on: ubuntu-latest
    if: github.event_name == 'pull_request'
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Check changelog format
        env:
          PR_NUMBER: ${{ github.event.pull_request.number }}
        run: |
          CHANGELOG_FILE=".changelog/pr-${PR_NUMBER}.txt"
          
          if [ ! -f "$CHANGELOG_FILE" ]; then
            echo "ℹ️ No changelog entry (optional)"
            exit 0
          fi
          
          # Validate format
          TYPE=$(grep "^type:" "$CHANGELOG_FILE" | sed 's/^type:[[:space:]]*//')
          DESC=$(grep "^description:" "$CHANGELOG_FILE" | sed 's/^description:[[:space:]]*//')
          PR=$(grep "^pr:" "$CHANGELOG_FILE" | sed 's/^pr:[[:space:]]*//')
          TICKET=$(grep "^ticket:" "$CHANGELOG_FILE" | sed 's/^ticket:[[:space:]]*//')
          
          if [ -z "$TYPE" ] || [ -z "$DESC" ] || [ -z "$PR" ] || [ -z "$TICKET" ]; then
            echo "::error::Changelog is missing required fields"
            exit 1
          fi
          
          echo "✅ Changelog format valid"
```

---

## 5. PR Comment with Changelog Reminder

Post a comment on PRs without changelog entries:

**File:** `.github/workflows/changelog-reminder.yml`

```yaml
name: Changelog Reminder

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  remind:
    runs-on: ubuntu-latest
    permissions:
      pull-requests: write
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Check for changelog
        id: check
        env:
          PR_NUMBER: ${{ github.event.pull_request.number }}
        run: |
          CHANGELOG_FILE=".changelog/pr-${PR_NUMBER}.txt"
          if [ -f "$CHANGELOG_FILE" ]; then
            echo "has_changelog=true" >> $GITHUB_OUTPUT
          else
            echo "has_changelog=false" >> $GITHUB_OUTPUT
          fi
      
      - name: Post reminder comment
        if: steps.check.outputs.has_changelog == 'false'
        uses: actions/github-script@v7
        with:
          script: |
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## 📝 Changelog Reminder
              
              This PR doesn't have a changelog entry yet. While not required, adding one helps track changes:
              
              \`\`\`bash
              ./scripts/create-changelog.sh ${{ github.event.pull_request.number }} <type> "<description>" [<ticket>]
              \`\`\`
              
              **Types:** breaking, feature, enhancement, bugfix, note, security, deprecation, internal
              
              See [.changelog/README.md](.changelog/README.md) for details.`
            })
```

---

## Customization Tips

### Change Jira Ticket Format

In the validation step, update the regex pattern:

```bash
# Change this:
if [ "$TICKET" != "N/A" ] && ! echo "$TICKET" | grep -qE "^(CDI|PDI)-[0-9]+$"; then

# To match your format:
if [ "$TICKET" != "N/A" ] && ! echo "$TICKET" | grep -qE "^(PROJ|TEAM)-[0-9]+$"; then
```

### Add Custom Change Types

Update the `VALID_TYPES` line:

```bash
VALID_TYPES="breaking|feature|enhancement|bugfix|note|security|deprecation|internal|yourtype"
```

### Skip Validation for Specific Branches

Add branch conditions:

```yaml
on:
  pull_request:
    branches:
      - main
      - develop
    branches-ignore:
      - 'dependabot/**'
      - 'renovate/**'
```

---

## Testing Workflows Locally

Use [act](https://github.com/nektos/act) to test workflows locally:

```bash
# Install act
brew install act  # macOS
# or
curl https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash  # Linux

# Test the changelog verification workflow
act pull_request -W .github/workflows/verify-changelog.yml
```

---

## Troubleshooting

### Workflow Not Triggering

- Ensure workflow file is in `.github/workflows/`
- Check the `on:` triggers match your use case
- Verify the workflow is enabled in repository settings

### Permission Errors

Add permissions to the workflow:

```yaml
jobs:
  job-name:
    permissions:
      contents: write
      pull-requests: write
```

### Script Not Found Errors

Make sure scripts are executable and in the repository:

```yaml
- name: Make scripts executable
  run: chmod +x scripts/*.sh
```

---

## Best Practices

1. **Keep validation optional** - Don't block PRs without changelogs
2. **Use informative messages** - Help contributors understand requirements
3. **Automate release notes** - Generate on tag push for consistency
4. **Test workflows** - Use act or draft PRs to test before deploying
5. **Document the process** - Link to .changelog/README.md in workflow output
