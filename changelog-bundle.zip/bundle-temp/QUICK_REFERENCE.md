# Quick Reference - Changelog Commands

Fast reference for common changelog operations.

## Creating Changelog Entries

### Basic Command

```bash
./scripts/create-changelog.sh <pr-number> <type> "<description>" [<ticket>]
```

### With Jira Ticket

```bash
./scripts/create-changelog.sh 123 feature "Added dark mode" CDI-456
```

### Without Jira Ticket

```bash
./scripts/create-changelog.sh 123 feature "Added dark mode"
# Press Enter when prompted, or:
./scripts/create-changelog.sh 123 feature "Added dark mode" N/A
```

---

## Change Types

| Type | Use When |
|------|----------|
| `breaking` | Breaking changes requiring user action |
| `feature` | New features or capabilities |
| `enhancement` | Improvements to existing features |
| `bugfix` | Bug fixes |
| `note` | Important notices or announcements |
| `security` | Security-related changes |
| `deprecation` | Deprecation announcements |
| `internal` | Internal changes (not published) |

---

## Examples by Type

### Breaking Changes

```bash
./scripts/create-changelog.sh 101 breaking "Renamed config.yml to app.config.yml" CDI-123
```

### New Features

```bash
./scripts/create-changelog.sh 102 feature "Added OAuth2 authentication support" CDI-456
```

### Enhancements

```bash
./scripts/create-changelog.sh 103 enhancement "Improved API response time by 40%" PDI-789
```

### Bug Fixes

```bash
./scripts/create-changelog.sh 104 bugfix "Fixed memory leak in connection pool" CDI-321
```

### Security Updates

```bash
./scripts/create-changelog.sh 105 security "Updated dependencies to patch CVE-2024-1234" N/A
```

### Deprecations

```bash
./scripts/create-changelog.sh 106 deprecation "Deprecated /v1/users endpoint - use /v2/users" CDI-654
```

### Notes

```bash
./scripts/create-changelog.sh 107 note "Python 3.8 support will be dropped in v2.0" N/A
```

### Internal Changes

```bash
./scripts/create-changelog.sh 108 internal "Refactored authentication module" N/A
```

---

## Release Management

### Generate Release Notes

```bash
./scripts/generate-release-notes.sh
```

**Output:**
- `GITHUB_RELEASE_NOTES.md` - Markdown format
- `RELEASE_NOTES.adoc` - AsciiDoc format

### Archive Changelog Entries

```bash
./scripts/archive-changelog.sh <version>
```

**Example:**

```bash
./scripts/archive-changelog.sh v1.2.3
```

**Result:** Moves `.changelog/pr-*.txt` to `.changelog/archive/v1.2.3/`

---

## File Locations

| File | Location |
|------|----------|
| Changelog entries | `.changelog/pr-<number>.txt` |
| Archived entries | `.changelog/archive/<version>/` |
| Release notes (MD) | `GITHUB_RELEASE_NOTES.md` |
| Release notes (AsciiDoc) | `RELEASE_NOTES.adoc` |
| Documentation | `.changelog/README.md` |
| Examples | `.changelog/FORMAT_EXAMPLES.md` |

---

## Changelog Entry Format

```
type: <type>
description: <description>
pr: <pr-number>
ticket: <jira-ticket-or-N/A>
```

**Example:**

```
type: feature
description: Added multi-factor authentication with TOTP support
pr: 123
ticket: CDI-456
```

---

## Validation Rules

### Required Fields
- ✅ `type` - Must be a valid type
- ✅ `description` - Cannot be empty
- ✅ `pr` - PR number
- ✅ `ticket` - Jira ticket or N/A

### Jira Ticket Format
- Valid: `CDI-123`, `PDI-456`, `N/A`
- Invalid: `CDI123`, `cdi-123`, `CDI-`

### No Length Limits
- Description can be as long as needed
- No character restrictions

---

## Common Workflows

### Adding Changelog to Existing PR

```bash
# 1. Get your PR number (e.g., from GitHub)
# 2. Create changelog entry
./scripts/create-changelog.sh 123 feature "Your description" CDI-456

# 3. Add and commit
git add .changelog/pr-123.txt
git commit -m "Add changelog entry"
git push
```

### Editing an Existing Entry

```bash
# Just edit the file directly
vim .changelog/pr-123.txt

# Or use your preferred editor
code .changelog/pr-123.txt

# Commit the changes
git add .changelog/pr-123.txt
git commit -m "Update changelog entry"
git push
```

### Previewing Release Notes

```bash
# Generate release notes
./scripts/generate-release-notes.sh

# View the output
cat GITHUB_RELEASE_NOTES.md

# Don't commit if just previewing
git restore GITHUB_RELEASE_NOTES.md RELEASE_NOTES.adoc
```

### Complete Release Process

```bash
# 1. Generate release notes
./scripts/generate-release-notes.sh

# 2. Review
cat GITHUB_RELEASE_NOTES.md

# 3. Commit release notes
git add GITHUB_RELEASE_NOTES.md RELEASE_NOTES.adoc
git commit -m "Generate release notes for v1.2.3"

# 4. Create tag
git tag -a v1.2.3 -m "Release v1.2.3"

# 5. Archive changelogs
./scripts/archive-changelog.sh v1.2.3

# 6. Commit archive
git add .changelog/archive/
git commit -m "Archive changelog entries for v1.2.3"

# 7. Push everything
git push origin main
git push origin v1.2.3
```

---

## Troubleshooting

### "Permission denied" Error

```bash
chmod +x scripts/*.sh
```

### "Invalid type" Error

Check you're using one of the valid types:
- breaking, feature, enhancement, bugfix, note, security, deprecation, internal

### "Invalid Jira ticket format" Error

Ticket must be:
- `CDI-###` or `PDI-###` (numbers only after dash)
- Or `N/A` (case sensitive)

### Script Not Found

```bash
# Use relative path
./scripts/create-changelog.sh ...

# Or absolute path
bash /full/path/to/scripts/create-changelog.sh ...
```

---

## Tips & Tricks

### Interactive Mode

Run without arguments to see usage:

```bash
./scripts/create-changelog.sh
```

### Bulk Archive

Archive multiple versions:

```bash
for ver in v1.0.0 v1.1.0 v1.2.0; do
  ./scripts/archive-changelog.sh $ver
done
```

### Find All Changelog Entries

```bash
ls .changelog/pr-*.txt
```

### Count Pending Changes

```bash
ls .changelog/pr-*.txt | wc -l
```

### View All Archived Versions

```bash
ls .changelog/archive/
```

### Check What's in Archive

```bash
ls .changelog/archive/v1.2.3/
```

---

## Script Locations

All scripts are in the `scripts/` directory:

- `create-changelog.sh` - Create entries
- `generate-release-notes.sh` - Generate release notes
- `archive-changelog.sh` - Archive processed entries
- `format-release-notes.sh` - Format output
- `check-scripts.sh` - Validate script syntax
- `pre-commit-noagent-check.sh` - Pre-commit hooks
- `run-integration-tests.sh` - Run tests

---

## Additional Resources

- `.changelog/README.md` - Complete documentation
- `.changelog/FORMAT_EXAMPLES.md` - Format examples
- `QUICK_START.md` - Getting started guide
- `INSTALLATION.md` - Installation instructions
- `GITHUB_ACTIONS_SNIPPETS.md` - CI/CD integration
- `README_SNIPPETS.md` - README templates
