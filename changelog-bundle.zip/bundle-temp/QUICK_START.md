# Quick Start Guide - Changelog System

Get up and running with the changelog system in 5 minutes!

## For Repository Maintainers

### 1. Install the System

```bash
# Copy scripts to your project
cp -r scripts/* YOUR_PROJECT/scripts/
chmod +x YOUR_PROJECT/scripts/*.sh

# Copy documentation
cp -r .changelog YOUR_PROJECT/.changelog/

# Add to your .gitignore (if you want to ignore test entries)
echo ".changelog/pr-*.txt" >> YOUR_PROJECT/.gitignore
```

### 2. Configure (Optional)

If you use different Jira prefixes, edit `scripts/create-changelog.sh`:

```bash
# Line ~51: Change the regex pattern
if ! [[ $JIRA_TICKET =~ ^(YOUR|PREFIX)-[0-9]+$ ]]; then
```

### 3. Add GitHub Actions (Optional)

Copy from `GITHUB_ACTIONS_SNIPPETS.md` to validate changelog format in PRs.

**Note:** Changelog entries are now optional - PRs won't fail without them!

---

## For Contributors

### Creating a Changelog Entry

When you create a PR, add a changelog entry:

```bash
./scripts/create-changelog.sh <pr-number> <type> "<description>" [<ticket>]
```

**Example:**
```bash
./scripts/create-changelog.sh 456 feature "Added dark mode support with user preferences" CDI-789
```

### Change Types

Choose the appropriate type for your change:

- **breaking** - Breaking changes that require user action
- **feature** - New features or capabilities
- **enhancement** - Improvements to existing features
- **bugfix** - Bug fixes
- **note** - Important notices
- **security** - Security-related changes
- **deprecation** - Deprecation announcements
- **internal** - Internal changes (won't appear in release notes)

### Jira Tickets

- If you have a Jira ticket: Include it (e.g., `CDI-123` or `PDI-456`)
- If you don't have a ticket: The script will prompt you, just press Enter for N/A
- You can also pass it as the 4th argument

### Full Examples

**With Jira ticket:**
```bash
./scripts/create-changelog.sh 123 bugfix "Fixed memory leak in connection pool" CDI-456
```

**Without Jira ticket:**
```bash
./scripts/create-changelog.sh 124 enhancement "Improved error messages for API validation"
# When prompted, just press Enter
```

**Internal change (won't be published):**
```bash
./scripts/create-changelog.sh 125 internal "Refactored database access layer"
```

### What Gets Created

The script creates a file at `.changelog/pr-<number>.txt` with this format:

```
type: feature
description: Added dark mode support with user preferences
pr: 456
ticket: CDI-789
```

### Commit and Push

```bash
git add .changelog/pr-<number>.txt
git commit -m "Add changelog entry for PR <number>"
git push
```

---

## For Release Managers

### Generating Release Notes

When ready to release:

```bash
# Generate release notes for the current version
./scripts/generate-release-notes.sh

# This creates:
# - GITHUB_RELEASE_NOTES.md (Markdown format)
# - RELEASE_NOTES.adoc (AsciiDoc format)
```

### What Happens

1. Reads all `.changelog/pr-*.txt` files
2. Groups changes by type
3. Skips changes with `type: internal`
4. Generates formatted release notes
5. Creates both Markdown and AsciiDoc versions

### Archive Changelog Entries

After releasing, archive the processed changelogs:

```bash
./scripts/archive-changelog.sh v1.2.3

# This moves all .changelog/pr-*.txt files to:
# .changelog/archive/v1.2.3/
```

### Complete Release Workflow

```bash
# 1. Generate release notes
./scripts/generate-release-notes.sh

# 2. Review the generated files
cat GITHUB_RELEASE_NOTES.md

# 3. Create git tag
git tag -a v1.2.3 -m "Release v1.2.3"

# 4. Archive changelogs
./scripts/archive-changelog.sh v1.2.3

# 5. Commit and push
git add .changelog/archive/
git commit -m "Archive changelog entries for v1.2.3"
git tag -a v1.2.3 -m "Release v1.2.3"
git push origin main v1.2.3
```

---

## Common Questions

**Q: Do I need a changelog entry for every PR?**  
A: No! Changelog entries are optional. The CI pipeline won't fail without them.

**Q: What if my change is just internal refactoring?**  
A: Use `type: internal` - it will be tracked but not published in release notes.

**Q: Can I edit a changelog entry after creating it?**  
A: Yes! Just edit the `.changelog/pr-<number>.txt` file directly.

**Q: What if I forgot to add a changelog entry?**  
A: You can add it anytime before the release. Just run the script with your PR number.

**Q: How do I see what will be in the next release?**  
A: Run `./scripts/generate-release-notes.sh` to preview the release notes.

**Q: Can I have long descriptions?**  
A: Yes! There's no character limit. Describe your changes as thoroughly as needed.

---

## Next Steps

- See `FORMAT_EXAMPLES.md` for examples of all change types
- See `GITHUB_ACTIONS_SNIPPETS.md` for CI/CD integration
- See `README_SNIPPETS.md` for documentation templates
- See `QUICK_REFERENCE.md` for command cheat sheet
