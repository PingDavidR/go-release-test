# README Snippets for Changelog System

Ready-to-paste sections for your project's README.md file.

---

## Option 1: Minimal Section

Add this to your "Contributing" section:

```markdown
### Changelog Entries

This project uses structured changelog entries. When submitting a PR, optionally create a changelog entry:

```bash
./scripts/create-changelog.sh <pr-number> <type> "<description>" [<ticket>]
```

See `.changelog/README.md` for details.
```

---

## Option 2: Detailed Section

Add this as a dedicated section in your README:

```markdown
## Changelog Process

### Creating Changelog Entries

When you create a pull request, you can add a changelog entry to document your changes:

```bash
./scripts/create-changelog.sh <pr-number> <type> "<description>" [<ticket>]
```

**Example:**
```bash
./scripts/create-changelog.sh 123 feature "Added dark mode support" CDI-456
```

### Change Types

- **breaking** - Breaking changes requiring migration
- **feature** - New features and capabilities  
- **enhancement** - Improvements to existing features
- **bugfix** - Bug fixes
- **note** - Important notices or announcements
- **security** - Security-related changes
- **deprecation** - Deprecation announcements
- **internal** - Internal changes (refactoring, tests) - not published in release notes

### Jira Integration

- If you have a Jira ticket, include it: `CDI-123` or `PDI-456`
- If not, the script will prompt you - just press Enter to use `N/A`

### Documentation

For complete details, examples, and format specifications, see:
- `.changelog/README.md` - Full documentation
- `.changelog/FORMAT_EXAMPLES.md` - Examples of all change types

### Release Process

Release notes are automatically generated from changelog entries using:
```bash
./scripts/generate-release-notes.sh
```

This creates `GITHUB_RELEASE_NOTES.md` and `RELEASE_NOTES.adoc` with all changes grouped by type (excluding internal changes).
```

---

## Option 3: Table Format

Add this for a more visual reference:

```markdown
## Changelog System

### Quick Reference

| Action | Command |
|--------|---------|
| Create entry | `./scripts/create-changelog.sh <pr#> <type> "<desc>" [<ticket>]` |
| Generate notes | `./scripts/generate-release-notes.sh` |
| Archive entries | `./scripts/archive-changelog.sh <version>` |

### Change Types

| Type | Description | Published in Release Notes |
|------|-------------|---------------------------|
| `breaking` | Breaking changes requiring user action | ✅ Yes |
| `feature` | New features and capabilities | ✅ Yes |
| `enhancement` | Improvements to existing features | ✅ Yes |
| `bugfix` | Bug fixes | ✅ Yes |
| `note` | Important notices | ✅ Yes |
| `security` | Security-related changes | ✅ Yes |
| `deprecation` | Deprecation announcements | ✅ Yes |
| `internal` | Internal changes (refactoring, tests) | ❌ No |

### Example Workflow

```bash
# 1. Create a PR and get the PR number (e.g., 123)

# 2. Create a changelog entry
./scripts/create-changelog.sh 123 feature "Added user authentication with OAuth2 support" CDI-456

# 3. Commit the changelog file
git add .changelog/pr-123.txt
git commit -m "Add changelog entry for PR 123"
git push
```

See `.changelog/README.md` for complete documentation.
```

---

## Option 4: Developer Workflow Section

Add this to a "Developer Guide" or "Contributing" section:

```markdown
## Developer Workflow

### 1. Create Your Feature Branch

```bash
git checkout -b feature/my-new-feature
```

### 2. Make Your Changes

Implement your feature, enhancement, or bug fix.

### 3. Create a Changelog Entry (Optional but Recommended)

```bash
./scripts/create-changelog.sh <pr-number> <type> "<description>" [<jira-ticket>]
```

**Examples:**

```bash
# With Jira ticket
./scripts/create-changelog.sh 123 feature "Added multi-factor authentication" CDI-789

# Without Jira ticket
./scripts/create-changelog.sh 124 bugfix "Fixed memory leak in connection pool"
# Press Enter when prompted for ticket

# Internal change (won't appear in release notes)
./scripts/create-changelog.sh 125 internal "Refactored database access layer"
```

**Available types:** breaking, feature, enhancement, bugfix, note, security, deprecation, internal

### 4. Commit Your Changes

```bash
git add .
git commit -m "Your commit message"
git push origin feature/my-new-feature
```

### 5. Create a Pull Request

Open a PR on GitHub. The CI pipeline will validate your changelog format (if present).

### 6. After Merge

Changelog entries are automatically included in the next release notes.
```

---

## Option 5: FAQ Section

Add this to address common questions:

```markdown
## Changelog FAQ

**Q: Do I need a changelog entry for every PR?**  
A: No, changelog entries are optional. However, they're recommended for changes that affect users or the public API.

**Q: What if my change is just internal refactoring?**  
A: Use `type: internal` - this tracks the change but excludes it from public release notes.

**Q: Can I edit a changelog entry after creating it?**  
A: Yes! Just edit the `.changelog/pr-<number>.txt` file directly.

**Q: What if I forgot to add a changelog entry?**  
A: You can add it anytime before the release by running the script with your PR number.

**Q: How long can my description be?**  
A: There's no length limit. Write as much detail as needed to clearly explain the change.

**Q: What's the changelog file format?**  
A: Simple key-value format:
```
type: feature
description: Added dark mode support with user preferences
pr: 123
ticket: CDI-456
```

**Q: Where can I see examples?**  
A: Check `.changelog/FORMAT_EXAMPLES.md` for examples of all change types.
```

---

## Option 6: Badges and Status

Add badges to show changelog system status:

```markdown
## Project Status

![Changelog System](https://img.shields.io/badge/changelog-structured-blue)
![Release Notes](https://img.shields.io/badge/release_notes-automated-green)

This project uses an automated changelog and release notes system. See `.changelog/README.md` for details.
```

---

## Option 7: Contributing Guidelines Section

Add this to `CONTRIBUTING.md`:

```markdown
## Changelog Entries

### When to Create a Changelog Entry

Create a changelog entry for PRs that include:

- ✅ New features or capabilities
- ✅ Bug fixes
- ✅ Breaking changes
- ✅ Security updates
- ✅ Deprecations
- ✅ Important notes or announcements

You may skip changelog entries for:

- ❌ Documentation-only changes (unless user-facing docs)
- ❌ Internal refactoring (or use `type: internal`)
- ❌ Typo fixes
- ❌ CI/CD configuration changes

### How to Create an Entry

Run the changelog script:

```bash
./scripts/create-changelog.sh <pr-number> <type> "<description>" [<jira-ticket>]
```

### Choosing the Right Type

- **breaking** - Requires users to change their code or configuration
- **feature** - Adds new functionality
- **enhancement** - Improves existing functionality
- **bugfix** - Fixes a bug
- **security** - Security-related changes (always include these!)
- **deprecation** - Marks features as deprecated
- **note** - Important information users should know
- **internal** - Internal changes that don't affect users (tracked but not published)

### Writing Good Descriptions

**Good descriptions:**
- ✅ "Added multi-factor authentication with TOTP and SMS backup options"
- ✅ "Fixed memory leak in connection pool that occurred during high concurrency"
- ✅ "Breaking: Renamed `config.yml` to `app.config.yml` - update your configuration files"

**Poor descriptions:**
- ❌ "Fixed bug"
- ❌ "Updated code"
- ❌ "Changes"

### Complete Examples

```bash
# New feature with Jira ticket
./scripts/create-changelog.sh 123 feature "Added GraphQL API with pagination and filtering support" CDI-789

# Bug fix without Jira ticket
./scripts/create-changelog.sh 124 bugfix "Fixed race condition in cache invalidation"
# (Press Enter when prompted for ticket)

# Breaking change
./scripts/create-changelog.sh 125 breaking "Removed deprecated /v1/users endpoint - use /v2/users instead" PDI-456

# Internal change
./scripts/create-changelog.sh 126 internal "Refactored authentication module to use dependency injection"
```

### Validation

If you create a changelog entry, the CI pipeline will validate:
- All required fields are present (type, description, pr, ticket)
- The type is valid
- The Jira ticket format is correct (if not N/A)

### Documentation

For complete documentation, see:
- `.changelog/README.md` - Full system documentation
- `.changelog/FORMAT_EXAMPLES.md` - Examples for each type
```

---

## Customization Notes

### Changing Jira Prefixes

If your organization uses different Jira prefixes, update all references:

```markdown
- If you have a Jira ticket, include it: `PROJ-123` or `TEAM-456`
```

### Adding Your Own Change Types

If you've added custom types to the scripts, document them:

```markdown
- **yourtype** - Description of what this type is for
```

### Linking to External Documentation

If you have a wiki or docs site:

```markdown
For complete documentation, see:
- [Changelog System Guide](https://docs.yourcompany.com/changelog)
- `.changelog/README.md` (in this repository)
```

---

## Pro Tips

1. **Place changelog info near contributing guidelines** - Developers will find it when they need it
2. **Include examples** - Show actual commands developers can copy/paste
3. **Explain the "why"** - Help developers understand the benefit
4. **Keep it brief** - Link to .changelog/README.md for details
5. **Update regularly** - Keep examples current with your actual process

---

## Complete Example README Structure

Here's how these snippets might fit into a complete README:

```markdown
# Your Project Name

[Project description]

## Installation

[Installation instructions]

## Usage

[Usage instructions]

## Development

### Getting Started

[Development setup]

### Making Changes

[Development workflow including changelog entry creation - use Option 4]

## Contributing

### Pull Request Process

[PR guidelines]

### Changelog Entries

[Changelog section - use Option 2 or 3]

## Release Process

[Release workflow]

## FAQ

[General FAQ including changelog FAQ - use Option 5]

## License

[License information]
```
