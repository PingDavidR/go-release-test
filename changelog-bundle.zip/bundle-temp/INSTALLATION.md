# Installation Guide - Changelog System

Complete step-by-step instructions for installing the changelog system in your repository.

## Prerequisites

- Git repository
- Bash shell (Linux, macOS, or WSL on Windows)
- Basic familiarity with shell scripts
- (Optional) GitHub Actions for automated validation

## Installation Steps

### Step 1: Extract the Bundle

```bash
# Extract to a temporary location
unzip changelog-bundle.zip -d /tmp/changelog-system
cd /tmp/changelog-system
```

### Step 2: Prepare Your Repository

```bash
# Navigate to your repository
cd /path/to/your/repository

# Create scripts directory if it doesn't exist
mkdir -p scripts
```

### Step 3: Copy Scripts

```bash
# Copy all scripts
cp /tmp/changelog-system/scripts/*.sh scripts/

# Make scripts executable
chmod +x scripts/*.sh

# Verify scripts are executable
ls -la scripts/
```

Expected output:
```
-rwxr-xr-x create-changelog.sh
-rwxr-xr-x generate-release-notes.sh
-rwxr-xr-x archive-changelog.sh
-rwxr-xr-x format-release-notes.sh
-rwxr-xr-x check-scripts.sh
-rwxr-xr-x pre-commit-noagent-check.sh
-rwxr-xr-x run-integration-tests.sh
```

### Step 4: Copy Documentation

```bash
# Copy the .changelog directory
cp -r /tmp/changelog-system/.changelog .

# Verify structure
ls -la .changelog/
```

Expected output:
```
README.md
FORMAT_EXAMPLES.md
```

### Step 5: Configure Git Ignore (Optional)

If you want Git to ignore individual changelog entries (tracking them per-branch only):

```bash
echo "" >> .gitignore
echo "# Changelog entries (tracked per branch)" >> .gitignore
echo ".changelog/pr-*.txt" >> .gitignore
```

**Note:** Most projects want to track changelog files, so this step is optional.

### Step 6: Customize for Your Project (Optional)

#### A. Change Jira Ticket Prefix

Edit `scripts/create-changelog.sh`:

```bash
# Find line ~51 (in the validation section)
if ! [[ $JIRA_TICKET =~ ^(CDI|PDI)-[0-9]+$ ]]; then
  
# Change to your prefixes:
if ! [[ $JIRA_TICKET =~ ^(PROJ|TEAM)-[0-9]+$ ]]; then
```

Also update line ~62 (in the prompt):
```bash
read -r -p "Enter Jira ticket (format CDI-## or PDI-##, leave empty if none): " JIRA_TICKET

# Change to:
read -r -p "Enter Jira ticket (format PROJ-## or TEAM-##, leave empty if none): " JIRA_TICKET
```

#### B. Add Custom Change Types

Edit `scripts/create-changelog.sh` line ~76:

```bash
VALID_TYPES=("breaking" "feature" "enhancement" "bugfix" "note" "security" "deprecation" "internal" "yourtype")
```

Edit `scripts/generate-release-notes.sh` to handle the new type in the grouping section (around line 150).

### Step 7: Test the Installation

```bash
# Create a test changelog entry
./scripts/create-changelog.sh 999 feature "Test installation" CDI-TEST

# Verify the file was created
cat .changelog/pr-999.txt

# Generate test release notes
./scripts/generate-release-notes.sh

# Check the output
cat GITHUB_RELEASE_NOTES.md

# Clean up test files
rm .changelog/pr-999.txt GITHUB_RELEASE_NOTES.md RELEASE_NOTES.adoc
```

### Step 8: Set Up GitHub Actions (Optional)

#### Option A: Validation Only (Recommended)

Create `.github/workflows/verify-changelog.yml`:

```yaml
name: Verify Changelog Format

on:
  pull_request:
    paths:
      - '.changelog/pr-*.txt'

jobs:
  verify:
    name: Verify Changelog Format
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
      
      - name: Verify Changelog Format
        run: |
          PR_NUMBER=${{ github.event.pull_request.number }}
          CHANGELOG_FILE=".changelog/pr-${PR_NUMBER}.txt"
          
          if [ -f "$CHANGELOG_FILE" ]; then
            echo "Validating changelog format..."
            
            # Check required fields
            TYPE=$(grep "^type:" "$CHANGELOG_FILE" | sed 's/^type:[[:space:]]*//')
            DESC=$(grep "^description:" "$CHANGELOG_FILE" | sed 's/^description:[[:space:]]*//')
            PR=$(grep "^pr:" "$CHANGELOG_FILE" | sed 's/^pr:[[:space:]]*//')
            TICKET=$(grep "^ticket:" "$CHANGELOG_FILE" | sed 's/^ticket:[[:space:]]*//')
            
            if [ -z "$TYPE" ] || [ -z "$DESC" ] || [ -z "$PR" ] || [ -z "$TICKET" ]; then
              echo "::error::Changelog is missing required fields"
              exit 1
            fi
            
            # Validate type
            VALID_TYPES="breaking|feature|enhancement|bugfix|note|security|deprecation|internal"
            if ! echo "$TYPE" | grep -qE "^($VALID_TYPES)$"; then
              echo "::error::Invalid changelog type: $TYPE"
              exit 1
            fi
            
            echo "✓ Changelog format is valid"
          else
            echo "No changelog file found (optional)"
          fi
```

See `GITHUB_ACTIONS_SNIPPETS.md` for more examples.

### Step 9: Update Project Documentation

Add to your `README.md`:

```markdown
## Contributing - Changelog Process

This project uses a structured changelog system. When creating a PR:

1. Run the changelog script:
   ```bash
   ./scripts/create-changelog.sh <pr-number> <type> "<description>" [<ticket>]
   ```

2. Commit the generated `.changelog/pr-<number>.txt` file

See `.changelog/README.md` for details and examples.
```

See `README_SNIPPETS.md` for more complete templates.

### Step 10: Commit the Changes

```bash
# Add all new files
git add scripts/ .changelog/ .github/

# Commit
git commit -m "Add changelog and release notes system"

# Push
git push origin main
```

## Verification Checklist

After installation, verify:

- [ ] Scripts are executable (`ls -la scripts/`)
- [ ] Documentation is accessible (`.changelog/README.md` exists)
- [ ] Test changelog entry creates successfully
- [ ] Test release notes generate successfully
- [ ] GitHub Actions workflow validates (if added)
- [ ] Team members can run scripts
- [ ] Project README documents the process

## Troubleshooting

### Scripts Not Executable

```bash
chmod +x scripts/*.sh
```

### "Command not found" Error

```bash
# Use explicit bash
bash scripts/create-changelog.sh 123 feature "test"

# Or use relative path
./scripts/create-changelog.sh 123 feature "test"
```

### Jira Validation Failing

Check the regex pattern in `scripts/create-changelog.sh` matches your ticket format.

### GitHub Actions Not Running

Ensure the workflow file is in `.github/workflows/` and committed to the repository.

## Next Steps

- Read `QUICK_START.md` for usage examples
- Review `FORMAT_EXAMPLES.md` for changelog type examples
- Check `QUICK_REFERENCE.md` for command reference
- See `GITHUB_ACTIONS_SNIPPETS.md` for advanced CI/CD integration

## Getting Help

- Check `.changelog/README.md` for detailed format documentation
- Review `FORMAT_EXAMPLES.md` for examples of all change types
- See existing changelog entries in `.changelog/archive/` for real examples
